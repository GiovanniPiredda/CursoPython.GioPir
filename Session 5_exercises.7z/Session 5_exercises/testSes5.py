nums = [25,13,6,17,9]
nums.sort()
print(nums)